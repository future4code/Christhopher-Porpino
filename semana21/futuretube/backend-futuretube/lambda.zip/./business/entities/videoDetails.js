"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class VideoDetails {
    constructor(id, title, description, url, userId, name, photo) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.url = url;
        this.userId = userId;
        this.name = name;
        this.photo = photo;
        this.getId = () => this.id;
        this.getTitle = () => this.title;
        this.getDescription = () => this.description;
        this.getUrl = () => this.url;
        this.getUserId = () => this.userId;
        this.getUserName = () => this.name;
        this.getUserPhoto = () => this.photo;
    }
}
exports.default = VideoDetails;
