"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const loginEndpoint_1 = require("./endpoints/users/loginEndpoint");
const getAllVideosEndpoint_1 = require("./endpoints/videos/getAllVideosEndpoint");
const signupEndpoint_1 = __importDefault(require("./endpoints/users/signupEndpoint"));
const getVideoDetailsEndpoint_1 = require("./endpoints/videos/getVideoDetailsEndpoint");
const app = express_1.default();
const cors = require("cors");
app.use(express_1.default.json());
app.use(cors());
app.post("/login", loginEndpoint_1.loginEndpoint);
app.get("/videos", getAllVideosEndpoint_1.getAllVideosEndpoint);
app.post("/user/signup", signupEndpoint_1.default);
app.get("/video-details", getVideoDetailsEndpoint_1.getVideoDetailsEndpoint);
exports.default = app;
